#feature-id DenoisingSuite : ChickadeeScripts > DenoisingSuite
#feature-icon  Denoising.svg
#feature-info This script implements different denoising algorithms using machine learning



#include <pjsr/StdButton.jsh>
#include <pjsr/StdIcon.jsh>
#include <pjsr/StdCursor.jsh>
#include <pjsr/Sizer.jsh>
#include <pjsr/FrameStyle.jsh>
#include <pjsr/NumericControl.jsh>
#include <pjsr/FileMode.jsh>
#include <pjsr/DataType.jsh>
#include <pjsr/ImageOp.jsh>
#include <pjsr/SampleType.jsh>
#include <pjsr/UndoFlag.jsh>
#include <pjsr/TextAlign.jsh>
#include <pjsr/FontFamily.jsh>
#include <pjsr/ColorSpace.jsh>
#include <pjsr/StarDetector.jsh>

#define VERSION "v1.0.3 beta"


// Determine platform and appropriate command/shell setup
let CMD_EXEC, SCRIPT_EXT;
if (CoreApplication.platform == "MACOSX" || CoreApplication.platform == "macOS") {
    CMD_EXEC = "/bin/sh";
    SCRIPT_EXT = ".sh";
} else if (CoreApplication.platform == "MSWINDOWS" || CoreApplication.platform == "Windows") {
    CMD_EXEC = "cmd.exe";
    SCRIPT_EXT = ".bat";
} else {
    console.criticalln("Unsupported platform: " + CoreApplication.platform);
}


// Define platform-agnostic folder paths
let pathSeparator = (CoreApplication.platform == "MSWINDOWS" || CoreApplication.platform == "Windows") ? "\\" : "/";
let scriptTempDir = File.systemTempDirectory + pathSeparator + "denoiseConfig";
let denoisingConfigFile = scriptTempDir + pathSeparator + "denoising_config.csv";

// Ensure the temp directory exists
if (!File.directoryExists(scriptTempDir)) {
    File.createDirectory(scriptTempDir);
}

// Define global parameters
var denoisingParameters = {
    targetView: undefined,
    targetWindow: undefined,
    targetMaskWindow: undefined,
    strideSize: 1024,
    denoisePythonToolsParentFolderPath: "",
    linearDenoise: true,

    save: function () {
        Parameters.set("linearDenoise", this.linearDenoise);
        Parameters.set("strideSize", this.strideSize);
        Parameters.set("denoisePythonToolsParentFolderPath", this.denoisePythonToolsParentFolderPath);
        this.savePathToFile();
    },

    load: function () {
        if (Parameters.has("strideSize"))
            this.strideSize = Number(Parameters.getString("strideSize"));
        if (Parameters.has("linearDenoise"))
            this.linearDenoise = Number(Parameters.getBoolean("linearDenoise"));
        if (Parameters.has("denoisePythonToolsParentFolderPath"))
            this.denoisePythonToolsParentFolderPath = Parameters.getString("denoisePythonToolsParentFolderPath");
        this.loadPathFromFile();
    },
    savePathToFile: function () {
        try {
            let file = new File;
            // console.writeln("Writing config file: " + denoisingConfigFile);
            file.createForWriting(denoisingConfigFile);
            file.outTextLn(this.denoisePythonToolsParentFolderPath);
            file.outTextLn(String(this.strideSize));
            file.outTextLn(String(Number(this.linearDenoise)));
            file.close();
        } catch (error) {
            console.warningln("Failed to save denoisePythonTools parent folder path: " + error.message);
        }
    },

    loadPathFromFile: function () {
        try {
            if (File.exists(denoisingConfigFile)) {
                let file = new File;
                // console.writeln("Reading config file: " + denoisingConfigFile);
                file.openForReading(denoisingConfigFile);
                let lines = File.readLines(denoisingConfigFile);
                if (lines.length > 0) {
                    this.denoisePythonToolsParentFolderPath = lines[0].trim();
                    this.strideSize = lines[1].trim();
                    this.linearDenoise = Boolean(Number(lines[2].trim()));
                }
                file.close();
            }
        } catch (error) {
            console.warningln("Failed to load denoisePythonTools parent folder path: " + error.message);
        }
    }
};

function SpacedVerticalSizer() {
    this.__base__ = VerticalSizer;
    this.__base__();
    this.scaledSpacing = 5;
    this.scaledMargin = 5;
}

SpacedVerticalSizer.addItem = function (item, stretchFactor = 0) {
    //console.warningln("Adding " + item.constructor.name + " to " + this.constructor.name);
    if (item.constructor.name == "Sizer" && this.parentControl != null && this.parentControl.constructor.name != "Dialog") {
        item.clearMargin([]);
    }
    this.items.push(item);
    if (stretchFactor > 0) {
        this.add(item, stretchFactor);
    } else {
        this.add(item);
    }
}


// Dialog setup, image selection, etc.
function denoisingDialog() {
    this.__base__ = Dialog;
    this.__base__();

    console.hide();
    denoisingParameters.load();

    this.title = new Label(this);
    this.title.text = "Denoising Suite " + VERSION;
    this.title.textAlignment = TextAlign_Center;

    this.description = new TextBox(this);
    this.description.readOnly = true;
    this.description.height = 50;
    this.description.maxHeight = 50;
    this.description.text = "This script implements different denoising " +
        "algorithms to deal with background noise that has not been completely removed with stacking." +
        "";
    this.description.setMinWidth(640);
    // this.description.setMinHeight(150);

    this.imageSelectionLabel = new Label(this);
    this.imageSelectionLabel.text = "Select Image:";
    this.imageSelectionLabel.textAlignment = TextAlign_Right | TextAlign_VertCenter;

    this.imageSelectionDropdown = new ComboBox(this);
    this.imageSelectionDropdown.editEnabled = false;

    this.imageSelectionDropdown.onItemSelected = (index) => {
        if (index >= 0) {
            let window = ImageWindow.windowById(this.imageSelectionDropdown.itemText(index));
            if (window && !window.isNull) {
                denoisingParameters.targetWindow = window;
            } else {
                console.writeln("No valid window selected for preview!");
                
                this.adjustToContents();
            }
        }
    };



    let windows = ImageWindow.windows;
    let activeWindowId = ImageWindow.activeWindow.mainView.id;
    for (let i = 0; i < windows.length; ++i) {
        this.imageSelectionDropdown.addItem(windows[i].mainView.id);
        if (windows[i].mainView.id === activeWindowId) {
            this.imageSelectionDropdown.currentItem = i;
            denoisingParameters.targetWindow = windows[i];
        }
    }

    this.imageSelectionSizer = new HorizontalSizer;
    this.imageSelectionSizer.spacing = 4;
    this.imageSelectionSizer.add(this.imageSelectionLabel);
    this.imageSelectionSizer.add(this.imageSelectionDropdown, 100);


    this.maskSelectionLabel = new Label(this);
    this.maskSelectionLabel.text = "Select mask (optional):";
    this.maskSelectionLabel.textAlignment = TextAlign_Right | TextAlign_VertCenter;

    this.maskSelectionDropdown = new ComboBox(this);
    this.maskSelectionDropdown.editEnabled = false;

    this.maskSelectionDropdown.onItemSelected = (index) => {
        if (index >= 0) {
            if (index < 1) {
                denoisingParameters.targetMaskWindow = undefined;
            }
            else {
                let window = ImageWindow.windowById(this.maskSelectionDropdown.itemText(index));
                if (window && !window.isNull) {
                    denoisingParameters.targetMaskWindow = window;
                } else {
                    console.writeln("No valid window selected for preview!");

                    this.adjustToContents();
                }
            }

        }
    };



    let windows = ImageWindow.windows;
    // let activeWindowId = ImageWindow.activeWindow.mainView.id;
    this.maskSelectionDropdown.addItem("<No Mask>");
    for (let i = 0; i < windows.length; ++i) {
        this.maskSelectionDropdown.addItem(windows[i].mainView.id);
        /*
        if (windows[i].mainView.id === activeWindowId) {
            this.maskSelectionDropdown.currentItem = i;
            denoisingParameters.targetMaskWindow = windows[i];
        }
        */
    }

    this.maskSelectionSizer = new HorizontalSizer;
    this.maskSelectionSizer.spacing = 4;
    this.maskSelectionSizer.add(this.maskSelectionLabel);
    this.maskSelectionSizer.add(this.maskSelectionDropdown, 100);




    var dlg = this;

    this.strideLabel = new Label(this);
    this.strideLabel.text = "Stride size: ";
    this.strideLabel.textAlignment = TextAlign_Right | TextAlign_VertCenter;

    this.strideComboBox = new ComboBox(this);
    this.strideComboBox.toolTip = "Increase this for some speed improvement\nDecrease this if your GPU runs out of memory";
    this.strideComboBox.addItem("256");
    this.strideComboBox.addItem("384");
    this.strideComboBox.addItem("512");
    this.strideComboBox.addItem("640");
    denoisingParameters.load();

    if (denoisingParameters.strideSize == 256) {
        this.strideComboBox.currentItem = 0;
    }
    else if (denoisingParameters.strideSize == 384) {
        this.strideComboBox.currentItem = 1;
    }
    else if (denoisingParameters.strideSize == 512) {
        this.strideComboBox.currentItem = 2;
    }
    else {
        this.strideComboBox.currentItem = 3;
    }

    this.strideComboBox.onItemSelected = (index) => {

        if (index == 0) {
            denoisingParameters.strideSize = 256;
        }
        else if (index == 1) {
            denoisingParameters.strideSize = 384;
        }
        else if (index == 2) {
            denoisingParameters.strideSize = 512;
        }
        else {
            denoisingParameters.strideSize = 640;
        }

        denoisingParameters.save();
    };

    

    this.linearCheckBox = new CheckBox(this);
    with (this.linearCheckBox) {
        toolTip = "Check if this is a linear image for star replacement with StarNet2"
        text = "Linear data";
        enabled = true;
        checked = denoisingParameters.linearDenoise;
        bindings = function () {
            this.checked = denoisingParameters.linearDenoise;
        }
        onCheck = function (value) {
            denoisingParameters.linearDenoise = value;
        }
    }


    this.strideSizer = new HorizontalSizer;
    this.strideSizer.spacing = 4;
    this.strideSizer.add(this.linearCheckBox);
    this.strideSizer.addStretch();
    this.strideSizer.add(this.strideLabel);
    this.strideSizer.add(this.strideComboBox);

        
    this.denoiseATab = new Control(this);

    this.denoiseADescription = new TextBox(this);
    this.denoiseADescription.readOnly = true;
    this.denoiseADescription.height = 80;
    this.denoiseADescription.maxHeight = 80;
    this.denoiseADescription.text = "This tab applies a machine learning denoising model that is the fastest of all the algorithms in this suite, but at very low and very high levels of noise " +
        "it sometimes incompletely denoises the image.";
    

    this.denoiseAButtonTab = new PushButton(this);
    this.denoiseAButtonTab.text = "Denoise Selected Image";
    this.denoiseAButtonTab.onClick = function () {
        var parent = this.parent;
        var grandparent = parent.parent;
        var greatgrandparent = grandparent.parent;
        var denoiseAlgorithm = 1;
        Console.show();
        let returnedDenoise = denoiseImageAsLinear(denoisingParameters.targetWindow.mainView, greatgrandparent, denoiseAlgorithm, denoisingParameters.linearDenoise);
        denoisingParameters.save();
        Console.writeln('Image denoised from algorithm A');
        Console.hide();
    };

    this.denoiseAButtonSizerTab = new HorizontalSizer;
    this.denoiseAButtonSizerTab.spacing = 4;
    this.denoiseAButtonSizerTab.add(this.denoiseAButtonTab);

    
    with (this.denoiseATab) {
        sizer = new VerticalSizer(this.denoiseATab);
        // sizer = new HorizontalSizer;
        sizer.add(this.denoiseADescription);

        sizer.spacing = 6;
        sizer.add(this.denoiseAButtonSizerTab);
        sizer.spacing = 6;
        sizer.addStretch();
    }

    // -----------------------------

    this.denoiseBTab = new Control(this);

    this.denoiseBDescription = new TextBox(this);
    this.denoiseBDescription.readOnly = true;
    this.denoiseBDescription.height = 80;
    this.denoiseBDescription.maxHeight = 80;
    this.denoiseBDescription.text = "This tab applies a machine learning denoising model that is the slowest of the algorithms, but it seems to provide the most accurate output  " +
        "in some instances.";


    this.denoiseBButtonTab = new PushButton(this);
    this.denoiseBButtonTab.text = "Denoise Selected Image";
    this.denoiseBButtonTab.onClick = function () {
        var parent = this.parent;
        var grandparent = parent.parent;
        var greatgrandparent = grandparent.parent;
        var denoiseAlgorithm = 2;
        Console.show();
        let returnedDenoise = denoiseImageAsLinear(denoisingParameters.targetWindow.mainView, greatgrandparent, denoiseAlgorithm, denoisingParameters.linearDenoise);
        denoisingParameters.save();
        Console.writeln('Image denoised from algorithm A');
        Console.hide();
    };

    this.denoiseBButtonSizerTab = new HorizontalSizer;
    this.denoiseBButtonSizerTab.spacing = 4;
    this.denoiseBButtonSizerTab.add(this.denoiseBButtonTab);


    with (this.denoiseBTab) {
        sizer = new VerticalSizer(this.denoiseBTab);
        // sizer = new HorizontalSizer;
        sizer.add(this.denoiseBDescription);

        sizer.spacing = 6;
        sizer.add(this.denoiseBButtonSizerTab);
        sizer.spacing = 6;
        sizer.addStretch();
    }


    // -----------------------------

    this.denoiseCTab = new Control(this);

    this.denoiseCDescription = new TextBox(this);
    this.denoiseCDescription.readOnly = true;
    this.denoiseCDescription.height = 80;
    this.denoiseCDescription.maxHeight = 80;
    this.denoiseCDescription.text = "This tab applies a machine learning denoising model that is relatively quick but may not completely smooth the image. The network model was " +
        "originally designed for deblurring motion blur.";


    this.denoiseCButtonTab = new PushButton(this);
    this.denoiseCButtonTab.text = "Denoise Selected Image";
    this.denoiseCButtonTab.onClick = function () {
        var parent = this.parent;
        var grandparent = parent.parent;
        var greatgrandparent = grandparent.parent;
        var denoiseAlgorithm = 3;
        Console.show();
        let returnedDenoise = denoiseImageAsLinear(denoisingParameters.targetWindow.mainView, greatgrandparent, denoiseAlgorithm, denoisingParameters.linearDenoise);
        denoisingParameters.save();
        Console.writeln('Image denoised from algorithm A');
        Console.hide();
    };

    this.denoiseCButtonSizerTab = new HorizontalSizer;
    this.denoiseCButtonSizerTab.spacing = 4;
    this.denoiseCButtonSizerTab.add(this.denoiseCButtonTab);


    with (this.denoiseCTab) {
        sizer = new VerticalSizer(this.denoiseCTab);
        // sizer = new HorizontalSizer;
        sizer.add(this.denoiseCDescription);

        sizer.spacing = 6;
        sizer.add(this.denoiseCButtonSizerTab);
        sizer.spacing = 6;
        sizer.addStretch();
    }


    // -----------------------------

    this.denoiseDTab = new Control(this);

    this.denoiseDDescription = new TextBox(this);
    this.denoiseDDescription.readOnly = true;
    this.denoiseDDescription.height = 80;
    this.denoiseDDescription.maxHeight = 80;
    this.denoiseDDescription.text = "This tab applies a machine learning denoising model that is relatively quick. It is a variant of the algorithm in Tab A and denoises each channel separately" +
        ".";


    this.denoiseDButtonTab = new PushButton(this);
    this.denoiseDButtonTab.text = "Denoise Selected Image";
    this.denoiseDButtonTab.onClick = function () {
        var parent = this.parent;
        var grandparent = parent.parent;
        var greatgrandparent = grandparent.parent;
        var denoiseAlgorithm = 5;
        Console.show();
        let returnedDenoise = denoiseImageAsLinear(denoisingParameters.targetWindow.mainView, greatgrandparent, denoiseAlgorithm, denoisingParameters.linearDenoise);
        denoisingParameters.save();
        Console.writeln('Image denoised from algorithm A');
        Console.hide();
    };

    this.denoiseDButtonSizerTab = new HorizontalSizer;
    this.denoiseDButtonSizerTab.spacing = 4;
    this.denoiseDButtonSizerTab.add(this.denoiseDButtonTab);


    with (this.denoiseDTab) {
        sizer = new VerticalSizer(this.denoiseDTab);
        // sizer = new HorizontalSizer;
        sizer.add(this.denoiseDDescription);

        sizer.spacing = 6;
        sizer.add(this.denoiseDButtonSizerTab);
        sizer.spacing = 6;
        sizer.addStretch();
    }




    this.denoiseTabBox = new TabBox(this);
    with (this.denoiseTabBox) {
        
        addPage(this.denoiseATab, "Denoise Algorithm A");
        addPage(this.denoiseBTab, "Denoise Algorithm B");
        addPage(this.denoiseCTab, "Denoise Algorithm C");
        addPage(this.denoiseDTab, "Denoise Algorithm D");
        this.denoiseTabBox.bindings = function () {
            this.enabled = denoisingParameters.targetView != null;
        }
    }



    
    this.lblState = new Label(this);
    this.lblState.text = "";

    this.lblStateSizer = new HorizontalSizer;
    this.lblStateSizer.spacing = 4;
    this.lblStateSizer.add(this.lblState);

    var progressValue = 0;

    this.progressBar = new Label(this);
    with (this.progressBar) {
        lineWidth = 1;
        frameStyle = FrameStyle_Box;
        textAlignment = TextAlign_Center | TextAlign_VertCenter;

        onPaint = function (x0, y0, x1, y1) {
            var g = new Graphics(dlg.progressBar);
            g.fillRect(x0, y0, x1, y1, new Brush(0xFFFFFFFF));
            if (progressValue > 0) {
                var l = (x1 - x0 + 1) * progressValue;
                g.fillRect(x0, y0, l, y1, new Brush(0xFF00EFE0));
            }
            g.end();
            text = (progressValue * 100).toFixed(0) + "%";
        }
    }

    this.progress = function (n) {
        progressValue = n;// Math.min(n, 1);
        dlg.progressBar.repaint();
    }

    // Wrench Icon Button for setting the SetiAstroDenoise parent folder path
    this.setupButton = new ToolButton(this);
    this.setupButton.icon = this.scaledResource(":/icons/wrench.png");
    this.setupButton.setScaledFixedSize(24, 24);
    this.setupButton.onClick = function () {
        let pathDialog = new GetDirectoryDialog;
        // let pathDialog = new OpenFileDialog;
        pathDialog.initialPath = denoisingParameters.denoisePythonToolsParentFolderPath;
        if (pathDialog.execute()) {
            denoisingParameters.denoisePythonToolsParentFolderPath = pathDialog.directory;
            denoisingParameters.save();
            // this.parent.correctionFileLabel.text = denoisingParameters.denoisePythonToolsParentFolderPath;


        }
    };
    
    // New Instance button
    this.newInstanceButton = new ToolButton(this);
    this.newInstanceButton.icon = this.scaledResource(":/process-interface/new-instance.png");
    this.newInstanceButton.setScaledFixedSize(24, 24);
    this.newInstanceButton.toolTip = "Save a new instance of this script";
    this.newInstanceButton.onMousePress = function () {
        this.dialog.newInstance();
    }.bind(this);

    this.undoRepairButton = new PushButton(this);
    this.undoRepairButton.text = "Undo";
    this.undoRepairButton.toolTip = "Undo the last repair";
    this.undoRepairButton.icon = ":/icons/undo.png";
    this.undoRepairButton.onClick = () => {
        if (denoisingParameters.targetWindow && !denoisingParameters.targetWindow.isNull) {
            denoisingParameters.targetWindow.undo();
        } else {
            console.writeln("No valid window selected for undo!");
        }
    };

    this.redoRepairButton = new PushButton(this);
    this.redoRepairButton.text = "Redo";
    this.redoRepairButton.toolTip = "Redo the last repair";
    this.redoRepairButton.icon = ":/icons/redo.png";
    this.redoRepairButton.onClick = () => {
        if (denoisingParameters.targetWindow && !denoisingParameters.targetWindow.isNull) {
            denoisingParameters.targetWindow.redo();
        } else {
            console.writeln("No valid window selected for redo!");
        }
    };

    this.buttonsSizer = new HorizontalSizer;
    this.buttonsSizer.spacing = 6;
    this.buttonsSizer.add(this.newInstanceButton);
    this.buttonsSizer.add(this.setupButton);
    this.buttonsSizer.addStretch();
    this.buttonsSizer.add(this.undoRepairButton);
    this.buttonsSizer.add(this.redoRepairButton);
    // this.buttonsSizer.addStretch();
    // this.buttonsSizer.add(this.okButton);
    // this.buttonsSizer.add(this.cancelButton);
    // this.buttonsSizer.addStretch();

    // Layout
    this.sizer = new VerticalSizer;
    this.sizer.margin = 6;
    this.sizer.spacing = 6;
    this.sizer.addStretch();
    this.sizer.add(this.title);
    this.sizer.add(this.description);
    this.sizer.addStretch();
    this.sizer.add(this.imageSelectionSizer);
    this.sizer.spacing = 6;
    this.sizer.add(this.maskSelectionSizer);
    this.sizer.spacing = 6;
    this.sizer.add(this.strideSizer);
    this.sizer.spacing = 6;
    this.sizer.add(this.denoiseTabBox);
    this.sizer.spacing = 6;
    
    this.sizer.add(this.lblStateSizer);
    this.sizer.spacing = 8;
    this.sizer.add(this.progressBar);
    this.sizer.spacing = 6;
    // this.sizer.add(this.denoiseStrengthSlider);
    // this.sizer.add(this.denoiseModeSizer);
    this.sizer.addStretch();

    


    // this.sizer.add(this.setupButton);
    this.sizer.addSpacing(12);
    this.sizer.add(this.buttonsSizer);

    this.windowTitle = "Denoising Suite Script";
    this.adjustToContents();


}
denoisingDialog.prototype = new Dialog;

function saveImageAsXISF(inputFolderPath, view) {
    // Obtain the ImageWindow object from the view's main window
    let imgWindow = view.isMainView ? view.window : view.mainView.window;

    if (!imgWindow) {
        throw new Error("Image window is undefined for the specified view.");
    }

    let fileName = imgWindow.mainView.id;  // Get the main view's id as the filename
    let filePath = inputFolderPath + pathSeparator + fileName + ".xisf";

    // Set the image format to 32-bit float if not already set
    imgWindow.bitsPerSample = 32;
    imgWindow.ieeefpSampleFormat = true;

    // Save the image in XISF format
    if (!imgWindow.saveAs(filePath, false, false, false, false)) {
        throw new Error("Failed to save image as 32-bit XISF: " + filePath);
    }

    console.writeln("Image saved as 32-bit XISF: " + filePath);
    return filePath;
}



// Function to wait for the output file indefinitely
function waitForFile(outputFilePath) {
    let pollingInterval = 1000;  // Poll every 1 second
    let postFindDelay = 2000;    // Delay of 2 seconds after finding the file

    console.writeln("Waiting for output file: " + outputFilePath);
    // Keep looping until the file exists
    while (!File.exists(outputFilePath)) {
        msleep(pollingInterval);
    }

    console.writeln("Output file found: " + outputFilePath);
    console.writeln("Waiting for " + (postFindDelay / 1000) + " seconds to ensure the file is completely saved.");
    msleep(postFindDelay);

    return true;
}




// Process the denoised image after waiting for it
function processOutputImage(outputFilePath, targetView) {
    if (!File.exists(outputFilePath)) {
        console.criticalln("Denoised file not found: " + outputFilePath);
        return;
    }

    let denoisedWindow = ImageWindow.open(outputFilePath)[0];
    if (denoisedWindow) {
        denoisedWindow.show();

        // Now apply PixelMath to replace the original image with the reverted, denoised image
        let pixelMath = new PixelMath;
        pixelMath.expression = "iif(" + denoisedWindow.mainView.id + " == 0, $T, " + denoisedWindow.mainView.id + ")";
        pixelMath.useSingleExpression = true;
        pixelMath.createNewImage = false;
        pixelMath.executeOn(targetView);  // Replace the target view (main image) with the denoised one

        // Close the denoised image window after PixelMath operation
        denoisedWindow.forceClose();

        // Try deleting the temporary denoised file
        try {
            File.remove(outputFilePath);
            console.writeln("Deleted denoised file: " + outputFilePath);
        } catch (error) {
            console.warningln("Failed to delete denoised file: " + outputFilePath);
        }
    } else {
        console.criticalln("Failed to open denoised image: " + outputFilePath);
    }
}



// Function to delete the input file
function deleteInputFile(inputFilePath) {
    try {
        if (File.exists(inputFilePath)) {
            File.remove(inputFilePath);
            console.writeln("Deleted input file: " + inputFilePath);
        } else {
            console.warningln("Input file not found: " + inputFilePath);
        }
    } catch (error) {
        console.warningln("Failed to delete input file: " + inputFilePath);
    }
}


// Main execution block for running the script
let dialog = new denoisingDialog();
console.show();
console.writeln("denoisingDialog process started.");
console.flush();

if (dialog.execute()) {
    let selectedIndex = dialog.imageSelectionDropdown.currentItem;
    let selectedView = ImageWindow.windows[selectedIndex];

    if (!selectedView) {
        console.criticalln("Please select an image.");
    } else {
        let artifactCorrectionFileWindow = ImageWindow.open(denoisingParameters.artifactCorrectionImageFile)[0];
        if (artifactCorrectionFileWindow) {
            artifactCorrectionFileWindow.show();
        }
    }
}




// Create batch file to run the denoise process
function createBatchFile(batchFilePath, exePath, inputFilePath, linearData, denoiserNumber) {
    let batchContent;

    if (CoreApplication.platform == "MACOSX" || CoreApplication.platform == "macOS") {
        batchContent = "#!/bin/sh\n";
        batchContent += "cd \"" + exePath + "\"\n";
        batchContent += 'osascript -e \'tell application "Terminal" to do script "' +
            exePath + "/Denoise ";  // Use the full path to the executable
        batchContent += "--denoiser " + denoiserNumber + " ";
        batchContent += "--stride_size " + denoisingParameters.strideSize + " ";
        batchContent += "--filename \"" + inputFilePath + "\"\n";
    } // Linux shell script
    else if (CoreApplication.platform == "MSWINDOWS" || CoreApplication.platform == "Windows") {
        console.writeln("denoising : " + inputFilePath);
        batchContent = "@echo off\n";
        batchContent += "cd /d \"" + exePath + "\"\n";
        batchContent += "start Denoise.exe ";
        batchContent += "--denoiser " + denoiserNumber + " ";
        batchContent += "--stride_size " + denoisingParameters.strideSize + " ";
        batchContent += "--filename \"" + inputFilePath + "\"\n";
    } else {
        console.criticalln("Unsupported platform: " + CoreApplication.platform);
        return false;
    }

    // Write the script to the specified path
    try {
        File.writeTextFile(batchFilePath, batchContent);
        console.writeln((CoreApplication.platform == "Linux") ?
            "Shell script created: " + batchFilePath :
            "Batch file created: " + batchFilePath);
    } catch (error) {
        console.criticalln("Failed to create batch/shell file: " + error.message);
        return false;
    }

    console.writeln("Finished creating batch file.");

    return true;
}




function denoiseImage(view, dlg, denoiserNumber) {
    let inputFolderPath = denoisingParameters.denoisePythonToolsParentFolderPath + pathSeparator + "working";
    let outputFolderPath = denoisingParameters.denoisePythonToolsParentFolderPath + pathSeparator + "working";
    // let outputFolderPath = denoisingParameters.denoisePythonToolsParentFolderPath;
    let outputFileName = view.id + "_restored.xisf";
    // let outputFileName = "Rotated_denoised.fits";
    let outputFilePath = outputFolderPath + pathSeparator + outputFileName;
    console.writeln("Output file path: " + outputFilePath);

    let inputFilePath = saveImageAsXISF(inputFolderPath, view);
    console.writeln("Input file path: " + inputFilePath);
    let batchFilePath = denoisingParameters.denoisePythonToolsParentFolderPath + pathSeparator + "run_denoisePython" + SCRIPT_EXT;

    let stars_only = false;

    if (createBatchFile(batchFilePath, denoisingParameters.denoisePythonToolsParentFolderPath, inputFilePath, denoisingParameters.linearDenoise, denoiserNumber)) {

        let process = new ExternalProcess;

        try {
            if (CoreApplication.platform == "MACOSX" || CoreApplication.platform == "macOS" || CoreApplication.platform == "Linux") {
                if (!process.start(CMD_EXEC, [batchFilePath])) {
                    console.writeln("denoisePython started.");
                    console.flush();
                    console.writeln("denoisePython finished inside loop.");
                }
            } else if (CoreApplication.platform == "MSWINDOWS" || CoreApplication.platform == "Windows") {
                if (!process.start(CMD_EXEC, ["/c", batchFilePath])) {
                    console.writeln("denoisePython started.");
                    console.flush();
                    console.writeln("denoisePython finished inside loop.");
                }
            }
        } catch (error) {
            console.criticalln("Error starting process: " + error.message);
        }


        // process.start(CMD_EXEC, ["/c", batchFilePath]);
        console.flush();
        console.writeln("denoisePython started.");
        console.flush();

        if (waitForFile(outputFilePath)) {
            processOutputImage(outputFilePath, view);
            deleteInputFile(inputFilePath);
        } else {
            console.criticalln("Output file not found within timeout.");
        }
    }

    dlg.lblState.text = 'Image denoised';
    processEvents();


    return true;
}


function denoiseImageAsLinear(view, dlg, denoiserNumber, denoiseAsLinear) {
    let intermediateImageWindow = new ImageWindow(view.image.width, view.image.height,
        view.image.numberOfChannels, // 1 channel for grayscale
        view.image.bitsPerSample,
        view.image.isReal,
        view.image.isColor
    );

    let intermediateImageView = intermediateImageWindow.mainView;
    intermediateImageView.beginProcess(UndoFlag_NoSwapFile);
    let intermediateImageImage = intermediateImageView.image;
    intermediateImageImage.apply(view.image);

    intermediateImageWindow.show();

    if (denoiseAsLinear) {
        dlg.lblState.text = 'Applying temporary auto STF';
        processEvents();

        let constantCalcWindow = new ImageWindow(view.image.width, view.image.height,
            view.image.numberOfChannels, // 1 channel for grayscale
            view.image.bitsPerSample,
            view.image.isReal,
            view.image.isColor
        );

        let constantCalcView = constantCalcWindow.mainView;
        constantCalcView.beginProcess(UndoFlag_NoSwapFile);
        let constantCalcImage = constantCalcView.image;
        constantCalcImage.apply(view.image);

        var P = new PixelMath;
        P.expression =
            "C = -2.8  ;\n" +
            "B = 0.20  ;\n" +
            "c = min(max(0,med($T)+C*1.4826*mdev($T)),1);\n" +
            "mtf(mtf(B,med($T)-c),max(0,($T-c)/~c))";
        P.expression1 = "";
        P.expression2 = "";
        P.expression3 = "";
        P.useSingleExpression = true;
        P.symbols = "C,B,c";
        P.clearImageCacheAndExit = false;
        P.cacheGeneratedImages = false;
        P.generateOutput = true;
        P.singleThreaded = false;
        P.optimization = true;
        P.use64BitWorkingImage = false;
        P.rescale = false;
        P.rescaleLower = 0;
        P.rescaleUpper = 1;
        P.truncate = true;
        P.truncateLower = 0;
        P.truncateUpper = 1;
        P.createNewImage = false;
        P.showNewImage = true;
        P.newImageId = "";
        P.newImageWidth = 0;
        P.newImageHeight = 0;
        P.newImageAlpha = false;
        P.newImageColorSpace = PixelMath.prototype.SameAsTarget;
        P.newImageSampleFormat = PixelMath.prototype.SameAsTarget;


        P.expression =
            "C = -2.8  ;\n" +
            "B = 0.25  ;\n" +
            "min(max(0,med($T)+C*1.4826*mdev($T)),1);";

        P.executeOn(constantCalcView);

        var C0 = constantCalcImage.sample(0, 0);

        Console.writeln("C0: " + C0);

        constantCalcImage.apply(view.image);

        var targetBackground = 0.25;

        P.expression = "mtf(" + targetBackground + ",med($T) - " + C0 + ");";

        P.executeOn(constantCalcView);

        var mtfConstant = constantCalcImage.sample(0, 0);

        Console.writeln("mtfConstant: " + mtfConstant);



        // ****************** Start here with the input image after the constants have been calculated

        intermediateImageImage.apply(view.image);

        P.expression = "max(0, ($T - " + C0 + ")/~" + C0 + ");";

        P.executeOn(intermediateImageView);

        P.expression = "mtf((" + mtfConstant + "), $T);";

        P.executeOn(intermediateImageView);

        // ****************** Do the operations on the autoSTF image here

        // -------->

        constantCalcWindow.show();
        constantCalcWindow.forceClose();
        // autoSTFWindow.forceClose();
    }

    dlg.lblState.text = 'Denoising with supplied denoising convolutional neural network';
    processEvents();

    var denoiseReturn = denoiseImage(intermediateImageView, dlg, denoiserNumber);

    if (denoiseAsLinear) {
        dlg.lblState.text = 'Reversing auto STF';
        processEvents();

        // ****************** Now reverse out of the autoSTF

        P.expression = "mtf((1 - " + mtfConstant + "), $T);";

        P.executeOn(intermediateImageView);

        P.expression = "max(0, ($T * ~" + C0 + ") + " + C0 + ");";

        P.executeOn(intermediateImageView);
    }

    var P = new PixelMath;
    P.expression =
        "" + intermediateImageView.id + "";
    P.expression1 = "";
    P.expression2 = "";
    P.expression3 = "";
    P.useSingleExpression = true;
    P.symbols = "C,B,c";
    P.clearImageCacheAndExit = false;
    P.cacheGeneratedImages = false;
    P.generateOutput = true;
    P.singleThreaded = false;
    P.optimization = true;
    P.use64BitWorkingImage = false;
    P.rescale = false;
    P.rescaleLower = 0;
    P.rescaleUpper = 1;
    P.truncate = true;
    P.truncateLower = 0;
    P.truncateUpper = 1;
    P.createNewImage = false;
    P.showNewImage = true;
    P.newImageId = "";
    P.newImageWidth = 0;
    P.newImageHeight = 0;
    P.newImageAlpha = false;
    P.newImageColorSpace = PixelMath.prototype.SameAsTarget;
    P.newImageSampleFormat = PixelMath.prototype.SameAsTarget;

    if (denoisingParameters.targetMaskWindow) {
        let maskView = View.viewById(dlg.maskSelectionDropdown.itemText(dlg.maskSelectionDropdown.currentItem));

        P.expression =
            "" + intermediateImageView.id + "*~" + maskView.id + "+" + view.id + "*" + maskView.id;

        P.executeOn(intermediateImageView);
    }





    P.expression =
        "" + intermediateImageView.id + "";

    P.executeOn(view);

    intermediateImageWindow.forceClose();

    return intermediateImageView;
}

